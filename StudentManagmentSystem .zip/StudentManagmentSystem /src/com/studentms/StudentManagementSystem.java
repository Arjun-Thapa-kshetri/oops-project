package com.studentms;

public class StudentManagementSystem {

	public static void main(String[] args) throws Exception {
		
		StudentMS.runApp();
	}

}
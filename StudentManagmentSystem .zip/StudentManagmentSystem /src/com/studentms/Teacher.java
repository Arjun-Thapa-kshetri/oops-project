package com.studentms;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Teacher {
	private String name;

	public Teacher() {

	}

	public Teacher(String name) {
		this.name = name;
	}

	// Add setter and getter methods for the instance variables
	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return this.name;
	}

	// Add instructor data into database using JDBC
	public void addTeacherToDb() {
		Connection conn = null;
		try {
			// Step 1: Connect to the database
			conn = DBConnection.getConnection();
			// Step 2: Create a statement
			String sql = "INSERT INTO teacher (name) VALUES (?)";
			PreparedStatement statement = conn.prepareStatement(sql);

			// Step 3: Set the parameters for the statement
			statement.setString(1, this.name);

			// Step 4: Execute the statement
			statement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				// Step 5: Close the connection
				conn.close();
			} catch (SQLException se) {
				se.printStackTrace();
			}
		}
	}

	// update instructor data in the database
	public boolean updateTeacherToDb(String updatedName) {
		Connection conn = null;
		try {
			// Step 1: Connect to the database
			conn = DBConnection.getConnection();
			// Step 2: Create a statement
			String sql = "UPDATE teacher SET name = ? WHERE name = ?";
			PreparedStatement statement = conn.prepareStatement(sql);

			// Step 3: Set the parameters for the statement
			statement.setString(1, updatedName);
			statement.setString(2, this.name);
			int updatedRow = statement.executeUpdate();
			return updatedRow > 0;
			// Step 4: Execute the
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	public boolean deleteTeacherFromDb(String name) throws Exception {
		try {
			Connection conn = DBConnection.getConnection();
			String sql = "Delete from teacher WHERE name=?";
			PreparedStatement statement = conn.prepareStatement(sql);
			statement.setString(1, name);
			statement.executeUpdate();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	// get instructor with name
	public void getTeacherWithName(String instructorName) throws Exception {
		Connection conn = null;
		try {
			conn = DBConnection.getConnection();
			PreparedStatement ps = conn.prepareStatement("SELECT * FROM teacher WHERE name = ?");
			ps.setString(1, instructorName);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				System.out.println(" Teacher Name: " + rs.getString(1));
			}
			rs.close();

			PreparedStatement ps1 = conn.prepareStatement("SELECT * FROM teacher_course WHERE teacher_name = ?");
			ps1.setString(1, instructorName);
			rs= ps1.executeQuery();
			ArrayList<String> courseCodes = new ArrayList<>();
			while (rs.next()) {
				System.out.println("Course/Course details taught by " + instructorName + " :");
				courseCodes.add(rs.getString(1));
			}
			rs.close();
			
			for (String code : courseCodes) {
				PreparedStatement ps2 = conn.prepareStatement("SELECT * FROM course WHERE code = ?");
				ps2.setString(1, code);
				rs = ps2.executeQuery();
				while (rs.next()) {
					System.out.println(("   course code :" + rs.getString(2) + "\n   course name: " + rs.getString(1)));
				}
				rs.close();

			}

			System.out.println();
			conn.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// get all instructors
	public static ArrayList<String> getAllTeachers() throws Exception {
		Connection conn = null;
		ArrayList<String> instructors = new ArrayList<>();
		try {
			conn = DBConnection.getConnection();
			PreparedStatement ps = conn.prepareStatement("SELECT * FROM teacher");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				instructors.add(rs.getString(1));
			}
			conn.close();
			return instructors;

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return instructors;
	}

}

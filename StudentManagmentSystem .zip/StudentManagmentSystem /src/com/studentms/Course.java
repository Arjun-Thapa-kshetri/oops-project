package com.studentms;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Course {
	private String name;
	private String code;
	private ArrayList<Teacher> teacher;
	private List<Student> students;

	public Course(String name, String code) {
		this.name = name;
		this.code = code;
	}
	public Course() {

	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public ArrayList<Teacher> getTeacher() {
		return teacher;
	}

	public void setTeacher(ArrayList<Teacher> teacher) {
		this.teacher = teacher;
	}

	public List<Student> getStudents() {
		return students;
	}

	public void setStudents(List<Student> students) {
		this.students = students;
	}

	public boolean addCourse() throws Exception {
		Connection conn = null;
		try {
			conn = DBConnection.getConnection();
			conn.setAutoCommit(false);
			String sql = "INSERT INTO course (name, code) VALUES (?,?)";
			PreparedStatement statement = conn.prepareStatement(sql);
			statement.setString(1, this.name);
			statement.setString(2, this.code);
			int courseInserted = statement.executeUpdate();
			statement.close();

			statement = conn.prepareStatement("INSERT INTO teacher_course (course_code, teacher_name) VALUES (?,?)");
			statement.setString(1, this.code);
			for (int i = 0; i < this.teacher.size(); i++) {
				statement.setString(2, this.teacher.get(i).getName());
				statement.addBatch();;
			}
			
			statement.executeBatch();
			statement.close();
			conn.commit();
			// returns false if course is not inserted otherwise returns true
			return courseInserted > 0;

		} catch (SQLException e) {
			e.printStackTrace();
			conn.rollback();
			
		}
		conn.close();
		return false;
	}

	//update course with existing id
	public boolean updateCourse(String existingCourseCode) throws Exception {
		Connection conn = null;
		try {
			conn = DBConnection.getConnection();
			conn.setAutoCommit(false);
			String sql = "UPDATE course set name=?, code = ? where code =?";
			PreparedStatement statement = conn.prepareStatement(sql);
			statement.setString(1, this.name);
			statement.setString(2, this.code);
			statement.setString(3, existingCourseCode);
			int updated = statement.executeUpdate();
			statement.close();
			
			String sql1 = "DELETE FROM teacher_course WHERE course_code=?";
			statement = conn.prepareStatement(sql1);
			statement.setString(1, existingCourseCode);
			statement.executeUpdate();
			statement.close();
			
			statement = conn.prepareStatement("INSERT INTO teacher_course (course_code, teacher_name) VALUES (?,?)");
			statement.setString(1, this.code);
			for (int i = 0; i < this.teacher.size(); i++) {
				statement.setString(2, this.teacher.get(i).getName());
				statement.addBatch();;
			}
			
			statement.executeBatch();
			
			
			statement.close();
			conn.commit();
			return updated > 0;

		} catch (SQLException e) {
			conn.rollback();
			e.printStackTrace();
		}
		return false;
	}

	public static boolean deleteCourse(String code) throws Exception {
		Connection conn = null;
		try {
			conn = DBConnection.getConnection();
			conn.setAutoCommit(false);
			//delete  in foreign table
			String sql = "DELETE FROM teacher_course WHERE course_code=?";
			PreparedStatement statement = conn.prepareStatement(sql);
			statement.setString(1, code);
			int deleted = statement.executeUpdate();
			statement.close();
			
		
			
			if(deleted>0) {
				//delete  in foreign table
				String sql2 = "DELETE FROM student_course WHERE course_code=?";
				statement = conn.prepareStatement(sql2);
				statement.setString(1, code);
				statement.close();
				String sql1 = "DELETE FROM course WHERE code=?";
				statement= conn.prepareStatement(sql1);
				statement.setString(1, code);
				statement.executeUpdate();
			}
			statement.close();
			conn.commit();
			return deleted>0;

		} catch (SQLException e) {
			conn.rollback();
			e.printStackTrace();
		}
		return false;
	}

	// method to get all courses
	public static Map<String, String> getCourses() throws Exception {
		Connection conn = null;
		HashMap<String, String> courseMap = new HashMap<>();
		try {
			conn = DBConnection.getConnection();
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("select * from course");
			while (rs.next()) {
				courseMap.put(rs.getString(2), rs.getString(1));
			}
			conn.close();
			return courseMap;

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return courseMap;
	}

	// method to get course with code
	public static void getCourseWithCode(String code) throws Exception {
		Connection conn = null;
		try {
			conn = DBConnection.getConnection();
			PreparedStatement ps = conn.prepareStatement("SELECT * FROM course WHERE code = ?");
			ps.setString(1, code);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				System.out.println("Details of course: ");
				System.out.println(("   course code :" + rs.getString(2) + "\n   course name: " + rs.getString(1)));
			}

			rs.close();
			ps.close();
			ps = conn.prepareStatement("SELECT * FROM teacher_course WHERE course_code = ?");
			ps.setString(1, code);
			rs = ps.executeQuery();

			while (rs.next()) {
				System.out.print("Course taught by: ");
				System.out.println("   " + rs.getString(2));
			}

			conn.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// method to get course with student id
	public static Map<String, String> getCourseWithId(int id) throws Exception {
		Connection conn = null;
		HashMap<String, String> courseMap = new HashMap<>();
		try {
			conn = DBConnection.getConnection();
			conn.setAutoCommit(false);
			String sql1 = "Select * from student_course where student_id= ?";
			PreparedStatement statement = conn.prepareStatement(sql1);
			statement.setInt(1, id);
			ResultSet rs = statement.executeQuery();
			ArrayList<String> courseCodes = new ArrayList<>();
			while (rs.next()) {
				courseCodes.add(rs.getString(2));
			}
			rs.close();
			statement.close();
			for (String code : courseCodes) {
				statement = conn.prepareStatement( "Select * from course where code= ?");
				statement.setString(1, code);
				rs = statement.executeQuery();
				while (rs.next()) {
					courseMap.put(rs.getString(2), rs.getString(1));
				}
			}
			statement.close();
			conn.commit();
			conn.close();
	
			return courseMap;

		} catch (SQLException e) {
			conn.rollback();
			e.printStackTrace();
		}
		return courseMap;
	}
}

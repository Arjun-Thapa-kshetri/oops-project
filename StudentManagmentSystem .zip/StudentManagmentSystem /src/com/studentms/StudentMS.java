package com.studentms;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class StudentMS {

	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

	public static void runApp() throws Exception {

		do {
			System.out.println("Student Management System" + "\n");
			System.out.println("  Enter 11/12/13/14 to Add/Update/Delete/Get Teacher \n "
					+ " Enter 21/22/23/24 to Add/Update/Delete/Get Course \n "
					+ " Enter 31/32/33/34 to Add/Update/Delete/Get Student\n ");
			System.out.println("Enter the number from above: ");
			String in = br.readLine();

			try {
				int enterNumber = Integer.parseInt(in);
				boolean isContinue = false;
				switch (enterNumber) {
				case 11:
					do {
						System.out.println("enter teacher name: ");
						String teacherName = br.readLine();
						Boolean IsDuplicate = CheckDuplicateEntry.check("teacher","name",teacherName);
						if (IsDuplicate){
							System.out.println("This teacher is already exist.");
							break;
						}
						Teacher teacher = new Teacher(teacherName);
						teacher.addTeacherToDb();
						System.out.println("teacher added");
						System.out.println("press y to continue or any key to back");
						String s = br.readLine();
						if (s.equals("y")) {
							isContinue = true;
						} else {
							isContinue = false;
						}

					} while (isContinue);
					break;

				case 12:
					do {
						System.out.println("enter teacher name to update: ");
						String teacherName = br.readLine();

						System.out.println("enter new teacher name to update: ");
						String newTeacherName = br.readLine();
						Boolean IsDuplicate = CheckDuplicateEntry.check("teacher","name",newTeacherName);
						if (IsDuplicate){
							System.out.println("This teacher is already exist.");
							break;
						}
						Teacher teacher = new Teacher(teacherName);
						boolean isUpdated = teacher.updateTeacherToDb(newTeacherName);

						if (isUpdated) {
							System.out.println("teacher updated");
						} else {
							System.out.println("invalid name");
						}

						System.out.println("press y to continue or any key to back");
						String s = br.readLine();
						if (s.equals("y")) {
							isContinue = true;
						} else {
							isContinue = false;
						}

					} while (isContinue);
					break;
				case 13:
					do {
						System.out.println("enter name to delete teacher details: ");
						String instructorName = br.readLine();
						Teacher instructor = new Teacher();
						instructor.deleteTeacherFromDb(instructorName);
						System.out.println("Teacher information is deleted with name: " + instructorName);
						System.out.println("press y to continue or any key to back");
						String s = br.readLine();
						if (s.equals("y")) {
							isContinue = true;
						} else {
							isContinue = false;
						}

					} while (isContinue);
					break;
				case 14:
					do {
						System.out.println("enter teacher name to get details:: ");
						String instructorName = br.readLine();
						Teacher teacher = new Teacher();
						teacher.getTeacherWithName(instructorName);
						System.out.println("press y to continue or any key to back");
						String s = br.readLine();
						if (s.equals("y")) {
							isContinue = true;
						} else {
							isContinue = false;
						}

					} while (isContinue);
					break;
				case 21:
					do {
						System.out.println("enter course name: ");
						String name = br.readLine();
						Boolean IsDuplicate = CheckDuplicateEntry.check("course","name",name);
						if (IsDuplicate){
							System.out.println("This course name is already exist.");
							break;
						}
						System.out.println("enter course code: ");
						String code = br.readLine();
						Boolean IsDuplicatecode = CheckDuplicateEntry.check("course","code",code);
						if (IsDuplicatecode){
							System.out.println("This course code is already exist.");
							break;
						}

						ArrayList<String> instructors = Teacher.getAllTeachers();
						if (instructors.isEmpty()) {
							System.out.println("there is no teacher available!");
							break;
						}
						int i = 1;
						for (String instructorName : instructors) {
							System.out.println(i++ + ": " + instructorName);
						}

						System.out.println("type number to select teacher for course for examples 1 or 1, 2: ");
						String selectedInstructor = br.readLine();

						ArrayList<String> selectedTeachersIndices = new ArrayList<>(
								Arrays.asList(selectedInstructor.split(",")));

						ArrayList<Teacher> teachers = new ArrayList<>();
						for (String indexStr : selectedTeachersIndices) {
							String teacherName = instructors.get(Integer.parseInt(indexStr.trim()) -1);
							Teacher teacherTobeAdded = new Teacher(teacherName);
							teachers.add(teacherTobeAdded);
						}

						Course course = new Course(name, code);
						course.setTeacher(teachers);
						course.addCourse();
						System.out.println("course added!");
						System.out.println("press y to continue or any key to back");
						String s = br.readLine();
						if (s.equals("y")) {
							isContinue = true;
						} else {
							isContinue = false;
						}

					} while (isContinue);
					break;
				case 22:
					do {
						System.out.println("enter course code to update: ");
						String existingCourseCode = br.readLine();

						System.out.println("enter course name: ");
						String name = br.readLine();
						System.out.println("enter course code: ");
						String code = br.readLine();
						Boolean IsDuplicate = CheckDuplicateEntry.check("course","code",code);
						if (IsDuplicate){
							System.out.println("This code is already exist.");
							break;
						}

						ArrayList<String> instructors = Teacher.getAllTeachers();
						if (instructors.isEmpty()) {
							System.out.println("there is no teacher available!");
							break;
						}
						int i = 1;
						for (String instructorName : instructors) {
							System.out.println(i++ + ": " + instructorName);
						}

						System.out.println("type number to select teacher for course for examples 1 or 1, 2: ");
						String selectedInstructor = br.readLine();

						ArrayList<String> selectedTeachersIndices = new ArrayList<>(
								Arrays.asList(selectedInstructor.split(",")));

						ArrayList<Teacher> teachers = new ArrayList<>();
						for (String indexStr : selectedTeachersIndices) {
							String teacherName = instructors.get(Integer.parseInt(indexStr.trim())-1);
							Teacher teacherTobeAdded = new Teacher(teacherName);
							teachers.add(teacherTobeAdded);
						}

						Course course = new Course(name, code);
						course.setTeacher(teachers);
						course.updateCourse(existingCourseCode);
						System.out.println("course updated!");
						System.out.println("press y to continue or any key to back");
						String s = br.readLine();
						if (s.equals("y")) {
							isContinue = true;
						} else {
							isContinue = false;
						}
					} while (isContinue);
					break;
				case 23:
					do {
						System.out.println("enter course_code to delete course details: ");
						String code = br.readLine();
						boolean isDeleted = Course.deleteCourse(code);
						if (!isDeleted) {
							System.out.println("No such code existed");
						} else {
							System.out.println("course deleted with code: " + code);
						}
						System.out.println("press y to continue or any key to back");
						String s = br.readLine();
						if (s.equals("y")) {
							isContinue = true;
						} else {
							isContinue = false;
						}

					} while (isContinue);
					break;
				case 24:
					do {
						System.out.println("enter course code to get details:: ");
						String code = br.readLine();
						Course.getCourseWithCode(code);
						System.out.println("press y to continue or any key to back");
						String s = br.readLine();
						if (s.equals("y")) {
							isContinue = true;
						} else {
							isContinue = false;
						}

					} while (isContinue);
					break;
				case 31:
					do {
						System.out.println("enter student id: ");
						int id = Integer.parseInt(br.readLine());
						Boolean IsDuplicate = CheckDuplicateEntry.check("student","id",id);
						if (IsDuplicate){
							System.out.println("This student id is already exist.");
							break;
						}
						System.out.println("enter student name: ");
						String name = br.readLine();
						System.out.println("enter Y/N for feePaidStatus: ");
						String isFeePaid = br.readLine();
						System.out.println("enter student address ");
						String address = br.readLine();
						System.out.println("enter father name ");
						String fatherName = br.readLine();

						// getting courses and storing in map
						Map<String, String> courseMap = Course.getCourses();

						if (courseMap.isEmpty()) {
							System.out.println("course is empty, please add course first!");
							break;
						}

						int courseIndex = 1;
						ArrayList<String> courseCodes = new ArrayList<String>();
						System.out.println("     course_code   course_name");

						for (String courseCode : courseMap.keySet()) {
							courseCodes.add(courseCode);
							String courseName = courseMap.get(courseCode);
							System.out.println(courseIndex + " - " + courseCode + " : " + courseName);
							courseIndex++;
						}

						System.out.println(
								"type numeric value to select courses eg: 1 or any numeric value for single course \n for multiple courses type numeric value like 1, 2: ");
						String keys = br.readLine();

						List<String> listOfKeys = new ArrayList<>(Arrays.asList(keys.split(",")));

						List<Course> addedCourses = new ArrayList<>();
						for (String key : listOfKeys) {
							String courseCode = courseCodes.get(Integer.parseInt(key.trim()) - 1);
							Course courseToAdd = new Course();
							courseToAdd.setCode(courseCode);
							addedCourses.add(courseToAdd);

						}

						// student

						Student student = new Student(name, id, isFeePaid, address, fatherName, addedCourses);
						student.addStudentToDb();

						System.out.println("student added!");
						System.out.println("press y to continue or any key to back");
						String s = br.readLine();
						if (s.equals("y")) {
							isContinue = true;
						} else {
							isContinue = false;
						}

					} while (isContinue);
					break;
				case 32:
					do {
						System.out.println("enter student id to update: ");
						int id = Integer.parseInt(br.readLine());
						System.out.println("enter new student name: ");
						String name = br.readLine();
						System.out.println("enter Y/N for feePaidStatus: ");
						String isFeePaid = br.readLine();
						System.out.println("enter student father name ");
						String fatherName = br.readLine();
						System.out.println("enter student address ");
						String address = br.readLine();

						Map<String, String> courseMap = Course.getCourses();

						if (courseMap.isEmpty()) {
							System.out.println("course is empty, please add course first!");
							break;
						}

						int courseIndex = 1;
						ArrayList<String> courseCodes = new ArrayList<String>();
						System.out.println("     course_code   course_name");

						for (String courseCode : courseMap.keySet()) {
							courseCodes.add(courseCode);
							String courseName = courseMap.get(courseCode);
							System.out.println(courseIndex + " - " + courseCode + " : " + courseName);
							courseIndex++;
						}

						System.out.println(
								"type numeric value to select courses eg: 1 or any numeric value for single course \n for multiple courses type numeric value like 1, 2: ");

						String keys = br.readLine();

						List<String> listOfKeys = new ArrayList<>(Arrays.asList(keys.split(",")));

						List<Course> addedCourses = new ArrayList<>();
						for (String key : listOfKeys) {
							String courseCode = courseCodes.get(Integer.parseInt(key.trim()) - 1);
							Course courseToAdd = new Course();
							courseToAdd.setCode(courseCode);
							addedCourses.add(courseToAdd);

						}

						// student
						Student student = new Student(name, id, isFeePaid, address, fatherName, addedCourses);
						student.updateStudentToDb();

						System.out.println("student Updated!");
						System.out.println("press y to continue or any key to back");
						String s = br.readLine();
						if (s.equals("y")) {
							isContinue = true;
						} else {
							isContinue = false;
						}

					} while (isContinue);
					break;
				case 33:
					do {
						System.out.println("Enter student id to delete: ");
						int id = Integer.parseInt(br.readLine());
						Student student = new Student();
						boolean isdeleted = student.deleteStudentFromDb(id);
						if(!isdeleted){
							System.out.println("There is no student with such id to delete");
						}
						else {
							System.out.println("Student information is deleted" + id);
						}
						System.out.println("press y to continue or any key to back");
						String s = br.readLine();
						if (s.equals("y")) {
							isContinue = true;
						} else {
							isContinue = false;
						}

					} while (isContinue);
					break;
				case 34:
					do {
						System.out.println("Enter student id to get details: ");
						int id = Integer.parseInt(br.readLine());
						Student student = new Student();
						student.getStudentFromDb(id);
						System.out.println("press y to continue or any key to back");
						String s = br.readLine();
						if (s.equals("y")) {
							isContinue = true;
						} else {
							isContinue = false;
						}

					} while (isContinue);
					break;
				default:
					System.out.println("Invalid choice");

				}

			} catch (Exception e) {
				System.out.println("Invalid choice");
			}

		} while (true);
	}

}

package com.studentms;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {

	public static Connection getConnection() throws Exception{
		Connection con = null;
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		con = DriverManager.getConnection("jdbc:mysql://localhost/studentdb", "root", "arjunthapa01");
		}catch(Exception e) {
			e.printStackTrace();
		}
		return con;
	}

}

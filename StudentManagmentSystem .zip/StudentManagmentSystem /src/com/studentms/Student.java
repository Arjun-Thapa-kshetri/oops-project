package com.studentms;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public class Student {
	private String name;
	private int id;
	private String isFeePaid;
	private String fatherName;
	private String address;
	private List<Course> courses;

	public String getIsFeePaid() {
		return isFeePaid;
	}

	public void setIsFeePaid(String isFeePaid) {
		this.isFeePaid = isFeePaid;
	}

	public String getFatherName() {
		return fatherName;
	}

	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}

	public Student(String name, int id, String isFeePaid, String address, String fatherName, List<Course> courses) {
		this.name = name;
		this.id = id;
		this.isFeePaid = isFeePaid;
		this.courses = courses;
		this.address = address;
		this.fatherName = fatherName;
	}

	public Student() {

	}

	// Add setter and getter methods for the instance variables
	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return this.name;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getId() {
		return this.id;
	}

	public void setFeePaid(String isFeePaid) {
		this.isFeePaid = isFeePaid;
	}

	public String getFeePaid() {
		return this.isFeePaid;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getAddress() {
		return this.address;
	}

	public void setCourses(List<Course> courses) {
		this.courses = courses;
	}

	public List<Course> getCourses() {
		return this.courses;
	}

	// Add student data into database using JDBC
	public boolean addStudentToDb() throws Exception {
		Connection conn = null;
		try {
			conn = DBConnection.getConnection();
			conn.setAutoCommit(false);
			String sql = "INSERT INTO student (name, id, isFeePaid,father_name, address) VALUES (?,?,?,?,?)";
			PreparedStatement statement = conn.prepareStatement(sql);
			statement.setString(1, this.name);
			statement.setInt(2, this.id);
			statement.setString(3, this.isFeePaid);
			statement.setString(4, this.fatherName);
			statement.setString(5, this.address);
			int inserted = statement.executeUpdate();
			statement.close();

			String sql1 = "INSERT INTO student_course (student_id, course_code) VALUES (?,?)";
			statement = conn.prepareStatement(sql1);
			statement.setInt(1, this.id);
			for (int i = 0; i < courses.size(); i++) {
				Course course = courses.get(i);
				statement.setString(2, course.getCode());
				statement.addBatch();;
			}
			
			statement.executeBatch();
			statement.close();
			conn.commit();
			return inserted > 0;

		} catch (SQLException e) {
			conn.rollback();
			e.printStackTrace();
		}
		return false;
	}

	// update student data in the database
	public boolean updateStudentToDb() throws Exception {
		Connection conn = null;
		try {
			conn = DBConnection.getConnection();
			conn.setAutoCommit(false);
			String sql = "UPDATE student SET name=?, isFeePaid=?, father_name =?, address =? WHERE id=?";
			PreparedStatement statement = conn.prepareStatement(sql);
			statement.setString(1, this.name);
			statement.setString(2, this.isFeePaid);
			statement.setInt(5, this.id);
			statement.setString(3, this.fatherName);
			statement.setString(4, this.address);
			int updated = statement.executeUpdate();
			statement.close();

			if (updated > 0) {
				String sql1 = "DELETE FROM student_course WHERE student_id=?";
				statement = conn.prepareStatement(sql1);
				statement.setInt(1, this.id);
				if (updated > 0) {
					String sql2 = "DELETE FROM student_course WHERE student_id=?";
					statement = conn.prepareStatement(sql2);
					statement.setInt(1, this.id);
					statement.executeUpdate();
					statement.close();
					statement.close();
				}

				statement = conn.prepareStatement("INSERT INTO student_course (student_id, course_code) VALUES (?,?)");
				statement.setInt(1, this.id);
				for (int i = 0; i < courses.size(); i++) {
					Course course = courses.get(i);
					statement.setString(2, course.getCode());
					statement.addBatch();;
				}
				
				statement.executeBatch();

			}
			statement.close();
			conn.commit();

			return updated > 0;
		} catch (SQLException e) {
			conn.rollback();
			e.printStackTrace();
		}
		return false;
	}

	// delete student data from the database
	public boolean deleteStudentFromDb(int id) throws Exception {
		Connection conn = null;
		try {
			conn = DBConnection.getConnection();
			conn.setAutoCommit(false);
			
			//delete in foreign table
			PreparedStatement statement = conn.prepareStatement("Delete from student_course WHERE student_id=?");
			statement.setInt(1, id);
			statement.executeUpdate();
			statement.close();
			
			String sql = "Delete from student WHERE id=?";
			statement = conn.prepareStatement(sql);
			statement.setInt(1, id);
			int deleted = statement.executeUpdate();
			statement.close();
			
			
			statement.close();
			conn.commit();
			return deleted > 0;
		} catch (SQLException e) {
			conn.rollback();
			e.printStackTrace();
		}
		return false;
	}

	// delete student data from the database
	public void getStudentFromDb(int id) throws Exception {
		Connection conn = null;
		try {
			conn = DBConnection.getConnection();
			String sql = "select * from student where id = ?";
			PreparedStatement statement = conn.prepareStatement(sql);
			statement.setInt(1, id);
			ResultSet rs = statement.executeQuery();
			if (rs.next()) {
				System.out.println("id= " + rs.getInt(2) + "\nname= " + rs.getString(1) + "\nisFeePaid= "
						+ rs.getString(3) + "\nfather name= " + rs.getString(4) + "\naddress =" + rs.getString(5));
			}
			else {
			System.out.println("This student id has no record");
			}
			Map<String, String> coursesMap = Course.getCourseWithId(id);
			if (!coursesMap.isEmpty()) {
				System.out.println("courses are:  ");
				System.out.println("-->course code -- course name<--");
			}
			for (Map.Entry<String, String> entry : coursesMap.entrySet()) {
				System.out.println("      " + entry.getKey() + "      " + entry.getValue());
			}
		} catch (SQLException e) {
			e.printStackTrace(); 
		}
	}
}

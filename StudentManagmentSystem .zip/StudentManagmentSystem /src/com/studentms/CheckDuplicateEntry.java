package com.studentms;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CheckDuplicateEntry{
    public static Boolean check(String tableName, String critera, Object obj) throws Exception {
        String strValue = null;
        int intValue = 0;
        if (obj instanceof String) {
            strValue = obj.toString();
        }
        else{
            String str = obj.toString();
             intValue = Integer.parseInt(str);


        }
        try {
            Connection conn = DBConnection.getConnection();
            String sql = String.format("select * from %1$s where %2$s = ?", tableName, critera);
            PreparedStatement statement = conn.prepareStatement(sql);
            if(strValue!=null){
                statement.setString(1, strValue);
            }
            else{
                statement.setInt(1, intValue);
            }
            ResultSet rs = statement.executeQuery();
            if (rs.next())
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;

    }
}
